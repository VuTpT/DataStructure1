package funix.vn.utils;

public class Constant {
	public static final String FILE_INPUT = "input.txt";
	public static final String FILE_OUTPUT_1 = "output1.txt";
	public static final String FILE_OUTPUT_2 = "output2.txt";
	public static final String FILE_OUTPUT_3 = "output3.txt";
	public static final String FILE_OUTPUT_4 = "output4.txt";
	public static final String FILE_OUTPUT_5 = "output5.txt";
}
